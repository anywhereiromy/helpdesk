module.exports = {
  slack: {
    HOOK_URL: 'https://hooks.slack.com/services/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',
    BOT_AVATAR: 'http://res.cloudinary.com/dwmfhnjid/image/upload/v1447942693/Screen_Shot_2015-11-19_at_14.06.50_mrexdh.png',
    USERNAME: '@helpdesk',
    CHANNEL: '#helpdesk_requests'
  }
};
